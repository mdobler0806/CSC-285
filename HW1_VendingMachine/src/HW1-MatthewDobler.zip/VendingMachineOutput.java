/*******************************************
 * Name: Matthew Dobler
 * Class: CSC-285
 * Date: 2/9/2024
 * Assignment: HW1_VendingMachine
 *******************************************/
public class VendingMachineOutput {
    public Product product;
    public double change;

    public VendingMachineOutput(Product product, double change) {
        this.product = product;
        this.change = change;
    }

}
